
package com.mycompany.pag196;


public class Pag196 {

    public static void main(String[] args) {
        Ejercicio9 e9 = new Ejercicio9();
        e9.printValues();
        
    }
}
