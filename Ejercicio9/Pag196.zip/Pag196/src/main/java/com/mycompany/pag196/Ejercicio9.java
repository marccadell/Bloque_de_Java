
package com.mycompany.pag196;


public class Ejercicio9 {
    
    private int num1 = 10;
    private int num2 = 55;
    private int num3 = 5;
    private int num4 = 25;
    private int numNegativo = 3;
    private int resultadoEntero;
    private double resultadoReal;
    private double resto;
    
    public void printValues(){
        System.out.println("Restale a 10 5: \t" + (num1 - 5)); 
        System.out.println("Haz una suma de 55 y 45: \t" + (num2 + 45));
        System.out.println("Pon el numero 3 en negativo: \t" + (numNegativo - 6));
        System.out.println("Multiplica 5 por 5: \t" + (num3 * 5));
        System.out.println("Divide 25 entre 7 con resultado entero: \t" + (resultadoEntero = num4 / 7));
        System.out.println("Divide 25 entre 7 con resultado real: \t" + (resultadoReal = num4 / 7.0));
        System.out.println("Calcula el resto de dividir 25 entre 4: \t" + (resto = num4 % 7));
 
    }
    
}
