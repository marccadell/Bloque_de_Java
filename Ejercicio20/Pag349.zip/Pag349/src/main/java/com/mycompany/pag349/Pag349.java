

package com.mycompany.pag349;


public class Pag349 {

    public static void main(String[] args) {
        Programa1 p1 = new Programa1();
     
        System.out.println("");
        System.out.println("> Primer Programa");
        System.out.println("____________");
        p1.PrimerPrograma();
        System.out.println("");
    }
}
