
package com.mycompany.pag349;


public class Programa1 {
    
    
    public void PrimerPrograma(){
        System.out.printf("%1$S\t %2$S %3$s%n", "NOMBRE", "APELLIDO1", "APELLIDO2");
        System.out.printf("%1$S\t %2$s%3$s\n", "NOMBRE", "apellido1", "apellido2");
        System.out.printf("%3$s, %2$s, %1$s\n", "Nombre", "apellido1", "apellido2");
        System.out.printf("\t %2$s", "", 22);
    }
}
