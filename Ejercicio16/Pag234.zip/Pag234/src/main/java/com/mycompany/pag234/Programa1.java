
package com.mycompany.pag234;


public class Programa1 {
    
    public void PrimerPrograma(){
        
        int numeroAleatorio = (int) (Math.random()*2+1);
        boolean aux ;
        
        if (numeroAleatorio == 1){
            System.out.println(aux = false);
            System.out.println("Negro");
        }
        else if (numeroAleatorio == 2){
            System.out.println(aux = true);
            System.out.println("Blanco");
        }
        
    }
}
