
package com.mycompany.pag234;

import java.util.Scanner;


public class Programa2 {
    
    public void SegundoPrograma(){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduce una temperatura: ");
        float num = sc.nextFloat();
        
        String clima = "";
        String tipoClima = "";
        
        System.out.println("");
        
        if (num <= 10){
            System.out.println(clima = "Climas Frios");
            if (num < 5){
                System.out.println(tipoClima = "Polar");
            }
            else if (num >= 5 && num < 10){
                System.out.println(tipoClima = "Alta Montaña");
            }
        }
        
        if (num >= 10 && num < 20){
            System.out.println(clima = "Climas Templados");
            if (num >= 10 && num < 13.5){
                System.out.println(tipoClima = "Oceánico");
            }
            else if (num >= 13.5 && num < 16.5){
                System.out.println(tipoClima = "Mediterraneo");
            }
            else if (num >= 16.5 && num < 20){
                System.out.println(tipoClima = "Continental");
            }
        }
        
        if (num >= 20){
            System.out.println(clima = "Climas Cálidos");
            if (num >= 20 && num < 23.5){
                System.out.println(tipoClima = "Ecuatorial");
            }
            else if (num >= 23.5 && num < 26.5){
                System.out.println(tipoClima = "Tropical");
            }
            else if (num >= 26.5){
                System.out.println(tipoClima = "Desértico");
            }
        }
        

    }
    
}
