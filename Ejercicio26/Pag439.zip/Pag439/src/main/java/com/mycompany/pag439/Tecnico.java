
package com.mycompany.pag439;

public class Tecnico extends Operario{
 
    private String puestoTecnico;
    private String categoriaTecnico;
    private String tipoTecnico;

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    /**
     * @return the puestoTecnico
     */
    public String getPuestoTecnico() {
        return puestoTecnico;
    }

    /**
     * @param puestoTecnico the puestoTecnico to set
     */
    public void setPuestoTecnico(String puestoTecnico) {
        this.puestoTecnico = puestoTecnico;
    }

    /**
     * @return the categoriaTecnico
     */
    public String getCategoriaTecnico() {
        return categoriaTecnico;
    }

    /**
     * @param categoriaTecnico the categoriaTecnico to set
     */
    public void setCategoriaTecnico(String categoriaTecnico) {
        this.categoriaTecnico = categoriaTecnico;
    }

    /**
     * @return the tipoTecnico
     */
    public String getTipoTecnico() {
        return tipoTecnico;
    }

    /**
     * @param tipoTecnico the tipoTecnico to set
     */
    public void setTipoTecnico(String tipoTecnico) {
        this.tipoTecnico = tipoTecnico;
    }
}
