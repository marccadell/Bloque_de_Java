
package com.mycompany.pag439;


public class Directivo extends Empleado{
    private String categoria;
    private float bonusSalario;

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    /**
     * @return the categoria
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     * @param categoria the categoria to set
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    /**
     * @return the bonusSalario
     */
    public float getBonusSalario() {
        return bonusSalario;
    }

    /**
     * @param bonusSalario the bonusSalario to set
     */
    public void setBonusSalario(float bonusSalario) {
        this.bonusSalario = bonusSalario;
    }
    
}
