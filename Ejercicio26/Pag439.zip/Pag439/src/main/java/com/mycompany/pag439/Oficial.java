
package com.mycompany.pag439;


public class Oficial extends Operario{
    
    private String tipoOperario;
    private String categoriaOperario;
    private String puestoOperario;

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    /**
     * @return the tipoOperario
     */
    public String getTipoOperario() {
        return tipoOperario;
    }

    /**
     * @param tipoOperario the tipoOperario to set
     */
    public void setTipoOperario(String tipoOperario) {
        this.tipoOperario = tipoOperario;
    }

    /**
     * @return the categoriaOperario
     */
    public String getCategoriaOperario() {
        return categoriaOperario;
    }

    /**
     * @param categoriaOperario the categoriaOperario to set
     */
    public void setCategoriaOperario(String categoriaOperario) {
        this.categoriaOperario = categoriaOperario;
    }

    /**
     * @return the puestoOperario
     */
    public String getPuestoOperario() {
        return puestoOperario;
    }

    /**
     * @param puestoOperario the puestoOperario to set
     */
    public void setPuestoOperario(String puestoOperario) {
        this.puestoOperario = puestoOperario;
    }
}
