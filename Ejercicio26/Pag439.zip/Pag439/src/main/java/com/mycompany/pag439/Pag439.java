

package com.mycompany.pag439;


public class Pag439 {

    public static void main(String[] args) {
        Operario o = new Operario();
        o.getNombre();
        o.getSalario();
        
        Directivo d = new Directivo();
        d.getNombre();
        d.getBonusSalario();
        
        Oficial of = new Oficial();
        of.getPuestoOperario();
        of.getTipoOperario();
        of.getCategoriaOperario();
        
        Tecnico t = new Tecnico();
        t.getPuestoTecnico();
        t.getTipoTecnico();
        t.getCategoriaTecnico();
        
    }
}
