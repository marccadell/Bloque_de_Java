
package com.mycompany.pag162;


public class ejercicio4 {
    
    public void tiposPrimitivos(){
        // Lógicos
        boolean exit = true;
        System.out.println("Boolean -> " + exit);
        
        //Caracter
        char letra = 'a';
        System.out.println("Char -> " + letra);
        
        //Númericos Enteros
        byte entero1 = 4;
        System.out.println("Byte -> " + entero1);
        short entero2 = 83;
        System.out.println("Short -> " + entero2);
        int entero3 = 1237;
        System.out.println("Int -> " + entero3);
        long entero4 = 9999;
        System.out.println("Long -> " + entero4);
        
        //Númericos reales
        float real1 = 34;
        System.out.println("Float -> " + real1);
        double real2 = 67.8;
        System.out.println("Double -> " + real2);
          
    }
    
}
