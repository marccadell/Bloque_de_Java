

package com.mycompany.pag162;


public class Pag162 {

    public static void main(String[] args) {
        ejercicio4 e4 = new ejercicio4();
        e4.tiposPrimitivos();
    }
    
}
