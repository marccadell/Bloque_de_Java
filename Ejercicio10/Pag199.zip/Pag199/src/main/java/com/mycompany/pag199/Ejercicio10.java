
package com.mycompany.pag199;


public class Ejercicio10 {
    
    private int numero = 0;
    
    public void Incrementar(){
        for (int i = 6; numero < i; numero++){
             System.out.println("Incrementamos el valor en 1: " + numero);
        }  
    }
    
    public void Decrementar(){
        for (int i = 0; numero > i; --numero){
             System.out.println("Decrementamos el valor en -1: " + numero);
        }  
    }
    
    
}
    
    
    

