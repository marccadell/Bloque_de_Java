

package com.mycompany.pag199;


public class Pag199 {

    public static void main(String[] args) {
        Ejercicio10 e10 = new Ejercicio10();
        e10.Incrementar();
        System.out.println("");
        e10.Decrementar();
        
    }
}
