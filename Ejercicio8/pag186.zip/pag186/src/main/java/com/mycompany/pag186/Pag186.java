

package com.mycompany.pag186;


public class Pag186 {

    public static void main(String[] args) {
        ejercicio8 e8 = new ejercicio8();
        e8.printValues();
    }
}
