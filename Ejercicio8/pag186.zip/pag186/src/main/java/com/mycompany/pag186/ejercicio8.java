
package com.mycompany.pag186;


public class ejercicio8 {
    
    public void printValues(){
        String nombre = "Marc";
        String apellido = "Adell Fernández";
        String calle = "C/ Marina, 33";
        String municipio = "Barcelona";
        String cp = "08024";
        char sexo = 'M';
        String mail = "teamplayer4508@gmail.com";
        
        System.out.println(nombre + "\n" + apellido + "\n\t"
        + calle + "\n\t" + municipio + "\s\n" + cp + "\n\t"
        + sexo + "\t\n" + mail);
    }

}
