
package com.mycompany.pag240;


class Programa2 {
    
    public void SegundoPrograma() {
        int cont = 1;
        
        do{
            if (cont <= 4){
                System.out.println("Iteración >>> " + cont);
            }
            else{
                System.out.println(cont);
            }
            cont++;
        }
        while (cont <= 10);{ 
            if (cont >= 5){
                cont++;
            }
        }
        
    }
    
    
}
