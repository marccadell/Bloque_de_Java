
package com.mycompany.pag240;


class Programa1 {

    public void PrimerPrograma() {
        int cont = 1;
        
        while (cont < 10){
            System.out.println("Contador +1 >>> " + cont);
            if (cont < 3){
               cont++;
            }
            else{
                System.out.println("Ha llegado a la tercera iteración"
                        + " por lo tanto salimos del bucle");
                break;
            }
            
        }
 
    }
    
}
