

package com.mycompany.pag235;


public class Pag235 {

    public static void main(String[] args) {
        Programa1 p1 = new Programa1();
        Programa2 p2 = new Programa2();
        
        System.out.println("");
        System.out.println("> Primer Programa");
        System.out.println("____________");
        p1.PrimerPrograma();
        System.out.println("");
        System.out.println("> Segundo Programa");
        System.out.println("____________");
        p2.SegundoPrograma();
        System.out.println("");
    }
}
