
package com.mycompany.pag235;


public class Programa2 {
    
    public void SegundoPrograma(){
        double number = 55;
        
        String positivo = "Es positivo";
        String negativo = "Es negativo";
        
        System.out.println(number >= 0 ? positivo : negativo);
    }
}
