
package com.mycompany.pag163;


public class ejercicio5 {
    
    public void rangoCircular(){
        byte num1 = (byte) (Byte.MAX_VALUE + 5);
        System.out.println("Rango Circular de " + ((Object)num1).getClass()
                .getSimpleName() + " = " + num1);
        
        short num2 = (short) (Short.MAX_VALUE + 25);
        System.out.println("Rango Circular de " + ((Object)num2).getClass()
                .getSimpleName() + " = " + num2);
        
        int num3 = (int) (Integer.MAX_VALUE + 10000);
        System.out.println("Rango Circular de " + ((Object)num3).getClass()
                .getSimpleName() + " = " + num3);
        
        long num4 = (long) (Long.MAX_VALUE + 20000);
        System.out.println("Rango Circular de " + ((Object)num4).getClass()
                .getSimpleName() + " = " + num4);  
    }
   
}
