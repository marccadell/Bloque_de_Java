
package com.mycompany.pag163;


public class Pag163 {

    public static void main(String[] args) {
        ejercicio5 e5 = new ejercicio5();
        e5.rangoCircular();
        
    }
    
}
