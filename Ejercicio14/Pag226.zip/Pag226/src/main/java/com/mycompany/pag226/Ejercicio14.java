
package com.mycompany.pag226;

import java.util.Scanner;


public class Ejercicio14 {
    
    
    public void ParoImpar(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduce un numero: ");
        int num = sc.nextInt();
        
        if (num % 2 == 0) {
            System.out.println("\nEs Par.");
        } else {
            System.out.println("\nEs Impar.");
        }
        
    }
    
    
    public void BlancoNegro(){
        int numeroAleatorio = (int) (Math.random()*2+1);
        if (numeroAleatorio == 1){
            System.out.println("Blanco");
        }else {
            System.out.println("Negro");
        }
        
    }
    
}
