

package com.mycompany.pag226;


public class Pag226 {

    public static void main(String[] args) {
        Ejercicio14 e14 = new Ejercicio14();
        e14.ParoImpar();
        System.out.println("\n----------------------\n");
        e14.BlancoNegro();
    }
}
