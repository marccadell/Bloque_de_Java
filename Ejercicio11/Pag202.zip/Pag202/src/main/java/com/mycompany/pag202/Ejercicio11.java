
package com.mycompany.pag202;


public class Ejercicio11 {
    
    private int num = 25;
    
    public void OperadoresAritmeticos(){
        System.out.println(num += 5);
        System.out.println(num -= 15);
        System.out.println(num *= 2);
        System.out.println(num /= 2);
        System.out.println(num %= 2);
        
    }
    
}
