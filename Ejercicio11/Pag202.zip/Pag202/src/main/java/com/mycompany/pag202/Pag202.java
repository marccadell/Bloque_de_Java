
package com.mycompany.pag202;


public class Pag202 {

    public static void main(String[] args) {
        Ejercicio11 e11 = new Ejercicio11();
        e11.OperadoresAritmeticos();
        
    }
}
