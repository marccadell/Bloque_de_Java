
package com.mycompany.pag575;

import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Programa1 extends JFrame{
    
    private JPanel panel = new JPanel();
    
    public Programa1(){
        setTitle("Fundación Esplai");
        setBounds(100, 200, 800, 600); 
        setLocationRelativeTo(null); 
        setResizable(false); 
        setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\BOOTCAMP\\C1\\JAVA\\Ejercicios\\Ejercicio22\\favicon.png"));
        this.getContentPane().setBackground(Color.darkGray);
        
        iniciarComponentes();
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
    
    private void iniciarComponentes(){
       colocarPaneles();
       colocarImagen();
       
    }
    
    private void colocarPaneles(){
        panel.setLayout(null); 
        panel.setBackground(Color.darkGray);
        this.getContentPane().add(panel);
    }
    
    private void colocarImagen(){
        //Etiqueta 3 - Etiqueta tipo imagen
        ImageIcon imagen = new ImageIcon("D:\\BOOTCAMP\\C1\\JAVA\\Ejercicios\\Ejercicio22\\fondo.jpg");
        JLabel etiqueta = new JLabel();
        etiqueta.setBounds(300, 180, 800, 200);
        etiqueta.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(200, 200, WIDTH)));
        panel.add(etiqueta);
        
    }
            
   
}
