

package com.mycompany.pag575;


public class Pag575 {

    public static void main(String[] args) {
        Programa1 programa = new Programa1();
        programa.setVisible(true);
        
        
    }
    
}
