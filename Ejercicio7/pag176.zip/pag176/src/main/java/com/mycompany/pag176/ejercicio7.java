
package com.mycompany.pag176;


public class ejercicio7 {
    
    public String printValues(String dataType, int size){ 
        return "El Tipo de Dato: " + dataType + "\n" + 
               "El Tamaño de Bits: " + size + " bits\n" +
               "El Rango Total es: " + Math.pow(2, size) + "\n" +
               "El Rango va desde " + "(" + (-(Math.pow(2, size)/2)) + ")" + 
               " hasta " + "(" + ((Math.pow(2, size)/2)-1) + ")" + "\n";
    }
    
}
