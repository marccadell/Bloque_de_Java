

package com.mycompany.pag176;


public class Pag176 {

    public static void main(String[] args) {
        ejercicio7 e7 = new ejercicio7();
        System.out.println("El Rango de " + Boolean.TYPE + " va desde " 
                + Boolean.TRUE + " hasta " + Boolean.FALSE + "\n");
        System.out.println("El Rango de " + Character.TYPE + " va desde " 
                + "0" + " hasta " + (Math.pow(2, Character.SIZE)-1) + "\n");
        System.out.println(e7.printValues("Byte", 8));
        System.out.println(e7.printValues("Short", 16));
        System.out.println(e7.printValues("Int", 32));
        System.out.println(e7.printValues("Long", 64));
        System.out.println(e7.printValues("Float", 32));
        System.out.println(e7.printValues("Double", 64));
        
    }
}
