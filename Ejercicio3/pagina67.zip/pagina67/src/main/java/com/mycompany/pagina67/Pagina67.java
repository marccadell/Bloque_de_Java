
package com.mycompany.pagina67;


public class Pagina67 {

    public static void main(String[] args) {
        ejercicio3 e3 = new ejercicio3();
        e3.algoritmo(10, 20);
    }
}
