
package com.mycompany.pagina67;


public class ejercicio3 {
    
    public void algoritmo(int num1, int num2){
        int suma = num1 + num2;
        System.out.println(suma);
        
    }
    
}
