
package com.mycompany.pag236;


public class Pag236 {

    public static void main(String[] args) {
        int fila = 12;
        for (int i = 1; i <= fila; i++){
            for (int j = 1; j <= fila-i; j++){
                System.out.print("");
            }
            for (int k = 0; k <= (i*2)-1; k++){
                if (k%2!=0){
                   System.out.print("**"); 
                }
            }           
            System.out.println(""); 
        }
        
        int fila2 = 2;
        for (int i = 1; i <= fila2; i++){
            for (int j = 1; j <= fila2-i; j++){
                System.out.print("          ");
                System.out.print("****\n");
                System.out.print("          ");
                System.out.print("****");
            }         
            System.out.println(""); 
        }

    }
}
