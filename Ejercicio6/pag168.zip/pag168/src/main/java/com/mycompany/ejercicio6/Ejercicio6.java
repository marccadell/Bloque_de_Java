

package com.mycompany.ejercicio6;


public class Ejercicio6 {
    
    public static void main(String[] args) {
       pag168 e6 = new pag168();
       e6.constantes();
   
    }
     
}
