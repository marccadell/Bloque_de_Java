

package com.mycompany.pag438;


public class Pag438 {

    public static void main(String[] args) {
        Persona p = new Persona();

    }
}
