
package com.mycompany.pag260;


public class Programa3 {
    
    public boolean TercerPrograma(){
        boolean verificar;
        int num = (int) (Math.random()*200+1);
        if (num % 2 == 0){
            System.out.println(verificar = true);
        }
        else{
            System.out.println(verificar = false);
        }
        
        return verificar;
    }
    
}
