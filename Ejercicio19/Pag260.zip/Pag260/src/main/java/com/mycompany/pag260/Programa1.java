
package com.mycompany.pag260;


public class Programa1 {
    
    public String JavaOrNull(String name){
        String falso = null;
        System.out.println(name == "java" ? name : falso);
        return name;
    }
    
}
