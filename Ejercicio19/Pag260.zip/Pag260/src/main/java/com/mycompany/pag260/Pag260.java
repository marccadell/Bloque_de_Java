

package com.mycompany.pag260;


public class Pag260 {

    public static void main(String[] args) {
        Programa1 p1 = new Programa1();
        Programa2 p2 = new Programa2();
        Programa3 p3 = new Programa3();
        
        System.out.println("");
        System.out.println("> Primer Programa");
        System.out.println("____________");
        p1.JavaOrNull("java");
        p1.JavaOrNull("habba");
        System.out.println("");
        System.out.println("> Segundo Programa");
        System.out.println("____________");
        p2.Login("admin", "1234");
        p2.Login("admin", "1234mynameisGustavo");
        System.out.println("");
        System.out.println("");
        System.out.println("> Tercer Programa");
        System.out.println("____________");
        System.out.println("Información* Par = True || Impar = False");
        p3.TercerPrograma();
        p3.TercerPrograma();
        p3.TercerPrograma();
        System.out.println("");
  
    }
}
