
package com.mycompany.pag260;


public class Programa2 {
    
    public String Login(String usuario, String pass){
        String login;
        if (usuario == "admin" && pass == "1234"){
            System.out.println(login = "Login true");
        }
        else{
            System.out.println(login = "Login false");
        }
        
        return login;
    }
    
}
