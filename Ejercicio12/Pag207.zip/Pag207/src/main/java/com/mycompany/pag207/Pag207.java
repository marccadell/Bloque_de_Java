
package com.mycompany.pag207;


public class Pag207 {

    public static void main(String[] args) {
        Ejercicio12 e12 = new Ejercicio12();
        e12.OperadoresRelacion();
    }
}
