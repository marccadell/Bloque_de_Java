
package com.mycompany.pag207;


public class Ejercicio12 {
   
    private int num1 = 1;
    private int num2 = 2;
    private int num3 = 3;
    private int num4 = 2;
    
    
    public void OperadoresRelacion(){
        System.out.println(num4 == num2);
        System.out.println(num2 == num3);
        System.out.println(num1 != num3);
        System.out.println(num2 != num2);
        System.out.println(num4 < num3);
        System.out.println(num3 < num1);
        System.out.println(num1 > num3);
        System.out.println(num2 > num4);
        System.out.println(num2 > num3);
        System.out.println(num2 <= num3);
        System.out.println(num2 <= num4);
        System.out.println(num2 <= num1);
        System.out.println(num1 >= num2);
    }
    
}
