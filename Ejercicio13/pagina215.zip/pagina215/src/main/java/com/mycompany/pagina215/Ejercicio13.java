
package com.mycompany.pagina215;


public class Ejercicio13 {
    private final boolean bool1 = true;
    private final boolean bool2 = false;
    private final boolean bool3 = false;
    
    public void OperadoresLogicos(){
        System.out.println(bool1 == !bool2);
        System.out.println(bool2 == !bool3);
        
    }
}
