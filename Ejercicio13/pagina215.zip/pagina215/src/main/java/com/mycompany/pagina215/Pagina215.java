

package com.mycompany.pagina215;


public class Pagina215 {

    public static void main(String[] args) {
        Ejercicio13 e13 = new Ejercicio13();
        e13.OperadoresLogicos();
    }
}
