

package com.mycompany.pag61;


public class Pag61 {

    public static void main(String[] args) {
        ejercicio2 e2 = new ejercicio2();
        e2.escape1();
        System.out.println("");
        e2.escape2();
        System.out.println("");
        e2.escape3();
        System.out.println("");
        e2.escape4();
        System.out.println("");
        e2.escape5();
        System.out.println("");
        e2.escape6();
        System.out.println("");
        e2.escape7();
        System.out.println("");
        
    }
}
