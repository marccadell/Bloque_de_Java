
package com.mycompany.pag61;


public class ejercicio2 {
    
    public void escape1(){
        System.out.println("Hello\nWorld");
    }
    public void escape2(){
        System.out.println("Hello\tWorld");
    }
    public void escape3(){
        System.out.println("Hello\\World");
    }
    public void escape4(){
        System.out.println("Hello\"World");
    }
    public void escape5(){
        System.out.println("Hello\'World");
    }
    public void escape6(){
        System.out.println("Hello\rWorld");
    }
    public void escape7(){
        System.out.println("Hello\bWorld");
    }
    
    
    
}
