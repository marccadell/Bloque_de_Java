
package com.mycompany.pag425;

import java.util.Scanner;

public final class Car {
    
    private String fuel;
    private double maxSpeed;

    
    public Car() {}
    
    public Car(String sFuel, double sMaxSpeed) {
        fuel = sFuel;
        maxSpeed = sMaxSpeed;
    }
    
    /**
     * @return the fuel
     */
    public String getFuel() {
        return fuel;
    }

    /**
     * @param fuel the fuel to set
     */
    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    /**
     * @return the maxSpeed
     */
    public double getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * @param maxSpeed the maxSpeed to set
     */
    public void setMaxSpeed(double maxSpeed) {
        this.maxSpeed = maxSpeed;
    }
    
    public void iniciar(){
        registroDatos();
        visualizar();
    }
    
    public void registroDatos(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el tipo de combustible: ");
        fuel = sc.nextLine();
        System.out.print("Introduce la máxima velocidad: ");
        maxSpeed = sc.nextDouble();
    }
    
    public void visualizar() {
        System.out.println("Fuel...........:\t" + fuel);
        System.out.println("MaxSpeed...........:\t" + maxSpeed + "Km/h");
    }

   
   
    
}
