

package com.mycompany.pag425;


public class Pag425 {

    public static void main(String[] args) {
        Car c = new Car();
        c.iniciar();
    }
    
}
