
package com.mycompany.pag549;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class ProgramaDialog {
    
    public void Programa(){
        JFrame frame = new JFrame();
        ImageIcon icon = new ImageIcon("D:\\BOOTCAMP\\C1\\JAVA\\Ejercicios\\Ejercicio23\\pizza.png");
        
        String[] options = new String[5];
        options[0] = "Si, me encanta!";
        options[1] = "No, puags!";
        options[2] = "Mejor una 4 quesos";
        options[3] = "Siguiente";
        options[4] = "Salir";
        
        String[] preguntas = new String[6];
        preguntas[0] = "¿Te gusta la pizza peperroni?";
        preguntas[1] = "¿Te gusta la pizza vegetariana?";
        preguntas[2] = "¿Te gusta la pizza diavola?";
        preguntas[3] = "¿Te gusta la pizza prosciutto?";
        preguntas[4] = "¿Te gusta la pizza pollo con barbacoa?";
        preguntas[5] = "¿Te gusto yo?";
        
        int option = JOptionPane.showOptionDialog(frame.getContentPane(), 
                "¿Te gusta la pizza con piña?", "Preguntas sobre comida", 
                0,JOptionPane.INFORMATION_MESSAGE, icon, 
                options, null);
        
        if (option == 3){
            for (int i = 0; i < preguntas.length; i++){
                String aux = preguntas[i];
                preguntas[i] = aux;
                
                JOptionPane.showOptionDialog(frame.getContentPane(), 
                preguntas[i], "Preguntas sobre comida", 
                0,JOptionPane.INFORMATION_MESSAGE, icon, 
                options, null);
            }
        }
        else{}
        
    }
}
