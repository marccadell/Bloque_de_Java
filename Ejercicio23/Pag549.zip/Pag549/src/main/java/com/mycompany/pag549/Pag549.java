

package com.mycompany.pag549;


public class Pag549 {

    public static void main(String[] args) {
        ProgramaDialog programa = new ProgramaDialog();
        programa.Programa();

    }
}
