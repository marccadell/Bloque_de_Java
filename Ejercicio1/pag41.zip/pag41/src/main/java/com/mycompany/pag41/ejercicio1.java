
package com.mycompany.pag41;


public class ejercicio1 {
    
    public void mensaje(){
        System.out.println("Hola desde mi primer programa Java (CMD)");
    }
    
    public void mensaje2(){
        System.out.println("I corazonsito Java");
    }
}
