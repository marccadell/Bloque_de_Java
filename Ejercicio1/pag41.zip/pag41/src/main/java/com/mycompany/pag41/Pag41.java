
package com.mycompany.pag41;


public class Pag41 {

    public static void main(String[] args) {
        ejercicio1 e1 = new ejercicio1();
        e1.mensaje();
        e1.mensaje2();
    }

    
}

