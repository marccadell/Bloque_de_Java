
package com.mycompany.pag352;


public class Programa1 {
    
    
    public void PrimerPrograma(){
        System.out.printf("\t\t %1$s\t\t %2$s\t %3$s\n","Nombre", "Director", "Año");
        System.out.printf("\t %1$s\n","-----------------------------------------------------");
        System.out.printf("\t\t%1$s\t %2$s\t\t %3$s\n","Pulp Fiction", 2002, "Tarantino");
        System.out.printf("\t\t%1$s\t %2$s\t\t %3$s\n","Kill Bill", 2005, "Tarantino");
        System.out.printf("\t\t%1$s\t\t %2$s\t\t %3$s\n","Rocky", 2007, "Stalonne");
        System.out.println("");
        System.out.printf("%1$s\t\t %2$s\t %3$s\n","Nombre", "Director", "Año");
        System.out.printf("%1$s\n","-----------------------------------------------------");
        System.out.printf("%1$s\t %2$s\t\t %3$s\n","Pulp Fiction", 2002, "Tarantino");
        System.out.printf("%1$s\t %2$s\t\t %3$s\n","Kill Bill", 2005, "Tarantino");
        System.out.printf("%1$s\t\t %2$s\t\t %3$s\n","Rocky", 2007, "Stalonne");
        
    }
}
