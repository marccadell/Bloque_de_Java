
package com.mycompany.pag352;


public class Pag352 {

    public static void main(String[] args) {
        Programa1 p1 = new Programa1();
     
        System.out.println("");
        System.out.println("> Primer Programa");
        System.out.println("____________");
        System.out.println("");
        p1.PrimerPrograma();
        System.out.println("");
        
    }
}
